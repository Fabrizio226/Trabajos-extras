import os

from dotenv import load_dotenv
from flask import Flask
from flask_bcrypt import Bcrypt

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY")
app.config["DATABASE"] = os.getenv("DB_NAME", "esquema_peluches")
bcrypt = Bcrypt(app)

from flask_app.controllers.usuarios import usuarios_bp
from flask_app.controllers.peluches import peluches_bp

app.register_blueprint(usuarios_bp)
app.register_blueprint(peluches_bp)
