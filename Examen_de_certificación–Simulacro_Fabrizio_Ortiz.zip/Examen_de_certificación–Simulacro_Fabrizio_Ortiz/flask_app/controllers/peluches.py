from functools import wraps

from flask import Blueprint, abort, flash, redirect, render_template, request, session, url_for

from flask_app.models.peluche import Peluche

peluches_bp = Blueprint("peluches", __name__, url_prefix="/peluches")


def requiere_sesion(vista):
    @wraps(vista)
    def protegida(*args, **kwargs):
        if not session.get("usuario_id"):
            flash("Inicia sesión para continuar.", "warning")
            return redirect(url_for("usuarios.acceso"))
        return vista(*args, **kwargs)

    return protegida


def obtener_peluche_propietario(peluche_id):
    peluche = Peluche.buscar_por_id(peluche_id)
    if not peluche:
        abort(404)
    if peluche["usuario_id"] != session["usuario_id"]:
        abort(403)
    return peluche


def validar_peluche(formulario, excluir_id=None):
    datos = {
        "nombre": formulario.get("nombre", "").strip(),
        "descripcion": formulario.get("descripcion", "").strip(),
    }
    errores = []
    if not 2 <= len(datos["nombre"]) <= 120:
        errores.append("El nombre debe tener entre 2 y 120 caracteres.")
    elif Peluche.nombre_en_uso(datos["nombre"], excluir_id):
        errores.append("Ya existe un peluche con ese nombre.")
    if not datos["descripcion"]:
        errores.append("La descripción no puede estar vacía.")
    if len(datos["descripcion"]) > 2000:
        errores.append("La descripción no puede superar los 2000 caracteres.")
    for error in errores:
        flash(error, "danger")
    return datos, not errores


@peluches_bp.get("")
@peluches_bp.get("/")
@requiere_sesion
def dashboard():
    return render_template("peluches/index.html", peluches=Peluche.listar())


@peluches_bp.route("/nuevo", methods=["GET", "POST"])
@requiere_sesion
def nuevo():
    valores = {"nombre": "", "descripcion": ""}
    if request.method == "POST":
        valores, valido = validar_peluche(request.form)
        if valido:
            peluche_id = Peluche.crear({
                **valores,
                "usuario_id": session["usuario_id"],
            })
            if peluche_id:
                flash("El peluche se publicó correctamente.", "success")
                return redirect(url_for("peluches.detalles", peluche_id=peluche_id))
            flash("No se pudo guardar el peluche. Inténtalo de nuevo.", "danger")
    return render_template("peluches/nuevo.html", valores=valores)


@peluches_bp.get("/<int:peluche_id>")
@requiere_sesion
def detalles(peluche_id):
    Peluche.incrementar_vistas(peluche_id)
    peluche = Peluche.buscar_por_id(peluche_id)
    if not peluche:
        abort(404)
    return render_template("peluches/detalles.html", peluche=peluche)


@peluches_bp.route("/<int:peluche_id>/editar", methods=["GET", "POST"])
@requiere_sesion
def editar(peluche_id):
    peluche = obtener_peluche_propietario(peluche_id)
    if request.method == "POST":
        datos, valido = validar_peluche(request.form, excluir_id=peluche_id)
        if valido:
            resultado = Peluche.actualizar(
                peluche_id,
                {**datos, "usuario_id": session["usuario_id"]},
            )
            if resultado is not False:
                flash("Los cambios se guardaron.", "success")
                return redirect(url_for("peluches.detalles", peluche_id=peluche_id))
            flash("No se pudieron guardar los cambios.", "danger")
        peluche.update(datos)
    return render_template("peluches/editar.html", peluche=peluche)


@peluches_bp.post("/<int:peluche_id>/eliminar")
@requiere_sesion
def eliminar(peluche_id):
    obtener_peluche_propietario(peluche_id)
    resultado = Peluche.eliminar(peluche_id, session["usuario_id"])
    if resultado is not False:
        flash("El peluche se eliminó de la lista.", "success")
    else:
        flash("No se pudo eliminar el peluche.", "danger")
    return redirect(url_for("peluches.dashboard"))


@peluches_bp.post("/<int:peluche_id>/adoptar")
@requiere_sesion
def adoptar(peluche_id):
    peluche = Peluche.buscar_por_id(peluche_id)
    if not peluche:
        abort(404)
    if peluche["adoptado_por"] is not None:
        flash("Este peluche ya fue adoptado.", "warning")
    elif Peluche.adoptar(peluche_id, session["usuario_id"]) == 1:
        flash("¡Gracias por adoptar este peluche!", "success")
    else:
        flash("Otro usuario acaba de adoptar este peluche.", "warning")
    return redirect(url_for("peluches.detalles", peluche_id=peluche_id))
