CREATE DATABASE IF NOT EXISTS esquema_peluches
	CHARACTER SET utf8mb4
	COLLATE utf8mb4_unicode_ci;

USE esquema_peluches;

CREATE TABLE IF NOT EXISTS usuarios (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(80) NOT NULL,
	apellido VARCHAR(80) NOT NULL,
	correo VARCHAR(254) NOT NULL,
	password VARCHAR(255) NOT NULL,
	creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_usuarios_correo (correo)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS peluches (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(120) NOT NULL,
	descripcion VARCHAR(2000) NOT NULL,
	usuario_id INT UNSIGNED NOT NULL,
	adoptado_por INT UNSIGNED NULL,
	vistas INT UNSIGNED NOT NULL DEFAULT 0,
	creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_peluches_nombre (nombre),
	KEY ix_peluches_usuario (usuario_id),
	CONSTRAINT fk_peluches_donante FOREIGN KEY (usuario_id)
		REFERENCES usuarios (id) ON DELETE CASCADE,
	CONSTRAINT fk_peluches_adoptante FOREIGN KEY (adoptado_por)
		REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;
