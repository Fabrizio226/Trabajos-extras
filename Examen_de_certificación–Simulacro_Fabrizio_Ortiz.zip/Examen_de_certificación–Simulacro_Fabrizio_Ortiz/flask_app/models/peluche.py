from flask import current_app

from flask_app.config.mysqlconnection import connectToMySQL


class Peluche:
    @staticmethod
    def _db():
        return connectToMySQL(current_app.config["DATABASE"])

    @classmethod
    def listar(cls):
        return cls._db().query_db(
            "SELECT peluches.*, donantes.nombre AS donante_nombre, "
            "donantes.apellido AS donante_apellido, "
            "adoptantes.nombre AS adoptante_nombre, "
            "adoptantes.apellido AS adoptante_apellido "
            "FROM peluches "
            "JOIN usuarios AS donantes ON donantes.id = peluches.usuario_id "
            "LEFT JOIN usuarios AS adoptantes ON adoptantes.id = peluches.adoptado_por "
            "ORDER BY peluches.id DESC"
        )

    @classmethod
    def buscar_por_id(cls, peluche_id):
        resultados = cls._db().query_db(
            "SELECT peluches.*, donantes.nombre AS donante_nombre, "
            "donantes.apellido AS donante_apellido, "
            "adoptantes.nombre AS adoptante_nombre, "
            "adoptantes.apellido AS adoptante_apellido "
            "FROM peluches "
            "JOIN usuarios AS donantes ON donantes.id = peluches.usuario_id "
            "LEFT JOIN usuarios AS adoptantes ON adoptantes.id = peluches.adoptado_por "
            "WHERE peluches.id = %(id)s LIMIT 1",
            {"id": peluche_id},
        )
        return resultados[0] if resultados else None

    @classmethod
    def nombre_en_uso(cls, nombre, excluir_id=None):
        query = "SELECT id FROM peluches WHERE nombre = %(nombre)s"
        datos = {"nombre": nombre}
        if excluir_id is not None:
            query += " AND id <> %(excluir_id)s"
            datos["excluir_id"] = excluir_id
        query += " LIMIT 1"
        return bool(cls._db().query_db(query, datos))

    @classmethod
    def crear(cls, datos):
        return cls._db().query_db(
            "INSERT INTO peluches (nombre, descripcion, usuario_id) "
            "VALUES (%(nombre)s, %(descripcion)s, %(usuario_id)s)",
            datos,
        )

    @classmethod
    def actualizar(cls, peluche_id, datos):
        return cls._db().query_db(
            "UPDATE peluches SET nombre = %(nombre)s, descripcion = %(descripcion)s "
            "WHERE id = %(id)s AND usuario_id = %(usuario_id)s",
            {**datos, "id": peluche_id},
        )

    @classmethod
    def eliminar(cls, peluche_id, usuario_id):
        return cls._db().query_db(
            "DELETE FROM peluches WHERE id = %(id)s AND usuario_id = %(usuario_id)s",
            {"id": peluche_id, "usuario_id": usuario_id},
        )

    @classmethod
    def incrementar_vistas(cls, peluche_id):
        return cls._db().query_db(
            "UPDATE peluches SET vistas = vistas + 1 WHERE id = %(id)s",
            {"id": peluche_id},
        )

    @classmethod
    def adoptar(cls, peluche_id, usuario_id):
        return cls._db().query_db(
            "UPDATE peluches SET adoptado_por = %(usuario_id)s "
            "WHERE id = %(id)s AND adoptado_por IS NULL",
            {"id": peluche_id, "usuario_id": usuario_id},
        )
